package etc;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Asignatura")
public class Asignatura implements Serializable {
	@Id
	@Column(name="Idasignatura")
	private String idasignatura;
	
	@Column(name="Nombre")
	private String nombre;
	
	@Column(name="Creditos")
	private int creditos;
	
	@Column(name="Cuatrimestre")
	private int cuatrimestre;
	
	@Column(name="Costebasico")
	private int costebasico;
	
	@ManyToOne
	@JoinColumn(name = "Idprofesor", referencedColumnName = "Idprofesor")
	private Profesor idprofesor;
	
	@ManyToOne
	@JoinColumn(name = "Idtitulacion", referencedColumnName = "Idtitulacion")
	private Titulacion idtitulacion;
	
	@Column(name="Curso")
	private int Curso;
	
	
	public Asignatura(){
		
	}
	
	public Asignatura(String idasignatura, String nombre, int creditos, int cuatrimestre, int costebasico,
			Profesor idprofesor, Titulacion idtitulacion, int curso) {
		this.idasignatura = idasignatura;
		this.nombre = nombre;
		this.creditos = creditos;
		this.cuatrimestre = cuatrimestre;
		this.costebasico = costebasico;
		this.idprofesor = idprofesor;
		this.idtitulacion = idtitulacion;
		Curso = curso;
	}

	public String getIdasignatura() {
		return idasignatura;
	}

	public void setIdasignatura(String idasignatura) {
		this.idasignatura = idasignatura;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCreditos() {
		return creditos;
	}

	public void setCreditos(int creditos) {
		this.creditos = creditos;
	}

	public int getCuatrimestre() {
		return cuatrimestre;
	}

	public void setCuatrimestre(int cuatrimestre) {
		this.cuatrimestre = cuatrimestre;
	}

	public int getCostebasico() {
		return costebasico;
	}

	public void setCostebasico(int costebasico) {
		this.costebasico = costebasico;
	}

	public Profesor getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(Profesor idprofesor) {
		this.idprofesor = idprofesor;
	}

	public Titulacion getIdtitulacion() {
		return idtitulacion;
	}

	public void setIdtitulacion(Titulacion idtitulacion) {
		this.idtitulacion = idtitulacion;
	}

	public int getCurso() {
		return Curso;
	}

	public void setCurso(int curso) {
		Curso = curso;
	}
	
	

	@Override
	public String toString() {
		return "Asignatura [idasignatura=" + idasignatura + ", nombre=" + nombre + ", creditos=" + creditos
				+ ", cuatrimestre=" + cuatrimestre + ", costebasico=" + costebasico + ", idprofesor=" + idprofesor
				+ ", idtitulacion=" + idtitulacion + ", Curso=" + Curso + ", alumno_asignatura=" 
				+ "]";
	}
	


}