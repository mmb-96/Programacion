/**
 * Clase que hace algunas funciona para la base de datos, se utiliza en la parte del menu y del submenu.
 */
/**
 * @author Manuel Melero
 */
package Laboral;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DB {
	private Connection con;
	private String sql;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	/**
	 * Constructor que inicia la conexion a la base de datos.
	 * @throws SQLException Error de la conexion
	 */
	public DB() throws SQLException {
		con = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.46:1521:xe", "Manuel", "Manuel");
	}
	
	/**
	 * Metodo que saca los empleados de la base de datos.
	 * @return Devuelve una lista de empleados
	 * @throws Exception
	 */
	public List<Empleado> mostarDatosTodos() throws Exception {
		ArrayList<Empleado> empleados = new ArrayList<>();
		sql = "Select * From Empleados";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		while (rs.next()){
			empleados.add(new Empleado(rs.getString(1), rs.getString(2), rs.getString(3).charAt(0), rs.getInt(4), rs.getInt(5)));
		}
		
		return empleados;
	}
	
	/**
	 * Metodo que busca a un empleado mediante su dni.
	 * @param dni Parametro de un empleado para ralizar su busqueda.
	 * @return Devuelve el sueldo de un empleado.
	 * @throws Exception
	 */
	public int salaraioDni(String dni) throws Exception {
		int sueldo = 0;
		sql = "Select Sueldo From Nominas Where dni = ? ";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, dni);
		rs = pstmt.executeQuery();
		
		while (rs.next()){
			sueldo = rs.getInt(1);
		}
		return sueldo;
	}
	
	/**
	 * Metodo que actualiza el sueldo de un empleado.
	 * @param dni Parametro de un empleado para ralizar su busqueda y actualizacion del sueldo.
	 * @return Devuevle un true si se ha producido un error.
	 * @throws Exception 
	 */
	public boolean actualizarSueldo(String dni) {
		boolean error = false;
		try {
			sql = "Select * From Empleados Where dni = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dni);
			rs = pstmt.executeQuery();
			
			while (rs.next()){
				Empleado a = new Empleado(rs.getString(1), rs.getString(2), rs.getString(3).charAt(0), rs.getInt(4), rs.getInt(5));
				sql = "UPDATE Nominas set sueldo = ? where dni = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(2, a.dni);
				pstmt.setInt(1, Nomina.sueldo(a));
				pstmt.execute();
			}
		} catch (Exception e) {
			e.printStackTrace();
			error = true;
		}

		return error;
	}
	
	/**
	 * Metodo para actualizar todos los salarios de los empleados.
	 * @return Devuevle un true si se ha producido un error.
	 */
	public boolean actualizarSueldoTodos() {
		boolean error = false;
		ArrayList<Empleado> empleados = new ArrayList<>();
		try {
			empleados = (ArrayList<Empleado>) mostarDatosTodos();
			for (Empleado emp : empleados) {
				sql = "UPDATE Nominas set sueldo = ? where dni = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(2, emp.dni);
				pstmt.setInt(1, Nomina.sueldo(emp));
				pstmt.execute();
			}
		} catch (Exception e) {
			e.printStackTrace();
			error = true;
		}
		return error;
	}
	
	/**
	 * Metodo para realizar una copia de seguridad en fichero de la base de datos.
	 * @param empleados Fichero doonde se guardaran los empleados.
	 * @param nominas Fichero donde se guardaran los salarios.
	 * @return Devuevle un true si se ha producido un error.
	 */
	public boolean backup(File empleados, File nominas) {
		boolean error = false;
		try {
			sql = "Select * From Nominas";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			BufferedWriter bws = new BufferedWriter(new FileWriter(nominas));
			
			while (rs.next()){
				bws.write(rs.getString(1) + "," + rs.getInt(2));
				bws.newLine();
			}
			bws.close();
			
			pstmt.clearBatch();
			sql = "Select * From Empleados";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			BufferedWriter bwe = new BufferedWriter(new FileWriter(empleados));
			
			while (rs.next()){
				bwe.write(rs.getString(1) + "," + rs.getString(2) + "," + rs.getString(3)+ "," + rs.getInt(4)+ "," + rs.getInt(5));
				bwe.newLine();
			}
			bwe.close();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
			error = true;
		}catch (IOException e) {
			e.printStackTrace();
			error=true;
		}
		return error;
	}
	
	/**
	 * Metodo para actualizar el nombre de un empleado.
	 * @param Dni Parametro para seleccionar al empleado a actualizar.
	 * @param nombre Parametro que vamos a actualizar del empleado.
	 * @return Devuevle un true si se ha producido un error
	 */
	public boolean actualizarNombre(String Dni, String nombre) {
		boolean error = false;
		try {
			sql = "Update Empleados set nombre = ? where dni = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(2, Dni);
			pstmt.setString(1, nombre);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			error = true;
		}
		return error;
	}
	
	/**
	 * Metodo para actualizar el sexo de un empleado.
	 * @param Dni Parametro para seleccionar al empleado a actualizar.
	 * @param sexo Parametro que vamos a actualizar del empleado.
	 * @return Devuevle un true si se ha producido un error
	 */
	public boolean actualizarSexo(String Dni, char sexo) {
		boolean error = false;
		try {
			sql = "Update Empleados set sexo = ? where dni = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(2, Dni);
			pstmt.setString(1, Character.toString(sexo));
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			error = true;
		}
		return error;
	}
	
	/**
	 * Metodo para actualizar la categoria de un empleado.
	 * @param Dni Parametro para seleccionar al empleado a actualizar.
	 * @param cat Parametro que vamos a actualizar del empleado, relacionado con la categoria.
	 * @return Devuevle un true si se ha producido un error
	 */
	public boolean actualizarCategoria(String Dni, int cat) {
		boolean error = false;
		try {
			sql = "Update Empleados set categoria = ? where dni = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(2, Dni);
			pstmt.setInt(1, cat);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			error = true;
		}
		return error;
	}
	
	/**
	 * Metodo para actualizar la categoria de un empleado.
	 * @param Dni Parametro para seleccionar al empleado a actualizar.
	 * @param anyos Parametro que vamos a actualizar del empleado.
	 * @return Devuevle un true si se ha producido un error
	 */
	public boolean actualizarAnyos(String Dni, int anyos) {
		boolean error = false;
		try {
			sql = "Update Empleados set anyos = ? where dni = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(2, Dni);
			pstmt.setInt(1, anyos);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			error = true;
		}
		return error;
	}
}