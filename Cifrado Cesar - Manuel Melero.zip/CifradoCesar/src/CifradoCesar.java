import java.util.Scanner;

/**
 * Implemente una funci�n que sirva para cifrar un texto con el conocido m�todo de C�sar. 
 * El criptosistema consiste en el desplazamiento de 3 caracteres en la posici�n del car�cter
 *  a cifrar, es decir, la A se sustituye por la D, la B por la E, �, la X por la A, la Y por la 
 *  B y la Z por la C. Por simplicidad, supondremos que el texto a cifrar solo contiene 
 *  caracteres alfab�ticos. Por tanto el ejercicio consiste en implementar la siguiente funci�n:
 *  
 *  public String cifradoCesar(String cadenaACifrar)
 *  
 *  La funci�n recibe como par�metro la cadena a cifrar y devuelve un objeto String con la cadena
 *  cifrada mediante el sistema de Cesar.
 *  
 *  Utiliza el abecedario ingles.
 *  
 *  @author Manuel Melero
 */

public class CifradoCesar {
	
	private static Scanner sc;
	
	public static void main(String[] args) {
		//Variables
		String cadena = null;
		sc = new Scanner(System.in);
		//Implementacion
		System.out.println("Introduce una frase:");
		cadena = sc.nextLine();
		System.out.println(cifradoCesar(cadena));
	}

	public static String cifradoCesar(String cadenaACifrar) {
		String cifrado = "";
		for(int i = 0; i < cadenaACifrar.length(); i++) {
			if (cadenaACifrar.charAt(i) == ' ' ) {
				cifrado += " ";
			}else if(cadenaACifrar.charAt(i) >= 'a' && cadenaACifrar.charAt(i) <= 'z') {
				if((cadenaACifrar.charAt(i) + 3) > 'z') {
					cifrado += (char) (cadenaACifrar.charAt(i) + 3 - 26);
				}else {
					cifrado += (char) (cadenaACifrar.charAt(i) + 3);
				}
			}else if(cadenaACifrar.charAt(i) >= 'A' && cadenaACifrar.charAt(i) <= 'Z') {
				if((cadenaACifrar.charAt(i) + 3) > 'Z') {
					cifrado += (char) (cadenaACifrar.charAt(i) + 3 - 26);
				}else {
					cifrado += (char) (cadenaACifrar.charAt(i) + 3);
				}	
			}
		}
		return cifrado;
	}
}
