package cine;

public class TestCine {
	public static void main(String [] args) throws Exception {
		
		CineImp cine = new CineImp("Nervion Plaza", "nervion", 20, true);
		CineImp cine2 = new CineImp("Alva Majo", "nervion", 20, false);
		
		System.out.println("Son iguales? "+ (cine.equals(cine2)?"si":"no"));
		System.out.println("Compara: "+ (cine.compareTo(cine2)<0?"cine1 va antes":"cine2 va antes"));
		
		Sesion sesion1 = new Sesion(1, "jurasic", 19);
		Sesion sesion2 = new Sesion(2, "batman", 1);
		
		cine.nuevasesion(sesion1);
		cine.nuevasesion(sesion2);
				
		System.out.println(cine.toString());
		System.out.println(cine2.toString());
				
	}

}
