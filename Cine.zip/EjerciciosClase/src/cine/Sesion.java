package cine;

public class Sesion implements Comparable<Sesion> {
	private int id;
	private String pelicula;
	private int nsalas;
	
	public Sesion(int id, String pelicula, int nsalas) {
		super();
		this.id = id;
		this.pelicula = pelicula;
		this.nsalas = nsalas;
	}

	public int getId() {
		return id;
	}

	public String getPelicula() {
		return pelicula;
	}

	public int getNsalas() {
		return nsalas;
	}

	@Override
	public String toString() {
		return id + ", " + pelicula+", "+nsalas;
	}

	@Override
	public int compareTo(Sesion o) {
		if (id > o.id) {
			return 1;
		}else if(id == o.id) {
			return 0;
		}else {
			return -1;
		}
	}
	
	
	
}
