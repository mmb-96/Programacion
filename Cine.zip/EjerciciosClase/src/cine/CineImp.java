package cine;

import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class CineImp implements Cine, Comparable<CineImp> {

	private String nombre;
	private String direccion;
	private int nsalas;
	private boolean accesible;
	
	private int totalsalassesiones;
	
	private SortedSet<Sesion> sesiones;
	
	
	
	public CineImp(String nombre, String direccion, int salas, boolean accesible) throws Exception {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		if (salas < 1) {
			throw new Exception("El cine no puede tener menos de 1 sala");
		}else {
			this.nsalas = salas;
		}
		this.accesible = accesible;
		totalsalassesiones = 0;
		sesiones = new TreeSet<Sesion>();
	}
	
	@Override
	public void nuevasesion(Sesion s) throws Exception {
		List<Integer> ids = new LinkedList<Integer>();
		if (nsalas >= s.getNsalas()) {
			for(Sesion ses : sesiones) {
				ids.add(ses.getId());
			}
			if (!ids.contains(s.getId())) {
				sesiones.add(s);
				totalsalassesiones += s.getNsalas();
				
				if (totalsalassesiones > nsalas) {
					throw new Exception("Numero de salas del cine estan al tope");
				}
			}else {
				throw new Exception("Id de sesion ya existente");
			}			
		}else {
			throw new Exception("La sesion no puede tener mas salas que el cine");
		}
	}
	
	public void eliminasesion(Sesion s) {
		sesiones.remove(s);
	}
	
	public String getNombre() {
		return nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public int getSalas() {
		return nsalas;
	}
	public boolean isAccesible() {
		return accesible;
	}
	public SortedSet<Sesion> getSesiones() {
		return sesiones;
	}
	
	@Override
	public boolean equals(Object cine) {
		if (nombre.equals(((CineImp) cine).getNombre()) && nsalas == ((CineImp) cine).getSalas() ){
			return true;
		}else {
			return false;
		}
	}

	@Override
	public String toString() {
		String acceso;
		if (accesible) {
			acceso = "accesible ";
		}else {
			acceso = "no accesible ";
		}
		return nombre + " ("+ nsalas + ") " + acceso;
	}

	@Override
	public int compareTo(CineImp o) {
		if (nsalas > o.nsalas) {
			return 1;
		}else if (nsalas < o.nsalas) {
			return -1;
		}else {
			if (nombre.compareTo(o.nombre) < 0 ) {
				return -1;
			}else {
				return 1;
			}
		}
	}

	
}
