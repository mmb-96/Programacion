package cine;

public interface Cine {

	public void nuevasesion(Sesion s) throws Exception;
	public void eliminasesion(Sesion s);
	
	public boolean equals(Object cine);
	
}
