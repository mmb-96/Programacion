package EJ10;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Ejercicio10 {

	public static void main(String[] args) {
		List<Integer> lista1 = new LinkedList<Integer>();
		
		lista1.add(1); lista1.add(2); lista1.add(4); lista1.add(3); lista1.add(6); lista1.add(7);
		
		System.out.println(ordenaTrozo(lista1, 2, 4));
		System.out.println(minimoEnTrozo(lista1, 2, 6));
		System.out.println(maximoEnTrozo(lista1, 2, 4));

	}
	
	public static <T extends Comparable<? super T>> List<T> ordenaTrozo(List<T> lista, int posIni, int posFin) {
		List<T> aux = lista.subList(posIni, posFin+1);
		Collections.sort(aux);
		Collections.reverse(aux);
		return lista;
	}
	
	public static <T extends Comparable<? super T>> Integer minimoEnTrozo(List<T> lista, int posIni, int posFin) {
		List<T> aux = lista.subList(posIni, posFin+1);
		int min = (int) Collections.min(aux);
		return min;
	}
	
	public static <T extends Comparable<? super T>> Integer maximoEnTrozo(List<T> lista, int posIni, int posFin) {
		List<T> aux = lista.subList(posIni, posFin+1);
		int max = (int) Collections.max(aux);
		return max;
	}

}
