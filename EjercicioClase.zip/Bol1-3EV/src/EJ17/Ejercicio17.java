package EJ17;

import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio17 {

	private static Scanner sx;
	
	public static void main(String[] args) {
		int media = 0;
		int contador = 0;
		String numeros;
		String[] array;
		Integer num;
		sx = new Scanner(System.in);
		
		System.out.println("Introduzca una serie de numeros");
		numeros = sx.nextLine();
		
		array = numeros.split(",");
		System.out.println(Arrays.toString(array));
		
		for (int i = 0; i < array.length; i++ ) {
			contador++;
			num = new Integer(array[i]);
			media += num;
		}
		System.out.println("La media es " + media/contador);
		
	}

}
