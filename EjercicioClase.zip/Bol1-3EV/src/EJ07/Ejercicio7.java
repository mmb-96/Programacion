package EJ07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Ejercicio7 {

	public static void main(String[] args) {
		
		List<Integer> numeros = new ArrayList<Integer>();
		List<Integer> numeros2 = new ArrayList<Integer>();
		numeros.add(1); numeros.add(0,2); numeros.add(0,3);
		Collections.addAll(numeros2, 1,2,3);
		numeros.addAll(0,numeros2);
		//Pintria 1, 2, 3, 3, 2, 1.
		System.out.println(numeros);
		// Pintaria 0
		System.out.println("Primer 1 en posici�n " + numeros.indexOf(1));
		// Pintaria 5
		System.out.println("�ltimo 1 en posici�n " + numeros.lastIndexOf(1));
		
		//Borra el de 3 posicion.
		numeros.remove(numeros.indexOf(3));
		//Obtiene el de 3 posicion y le suma 1.
		numeros.set(2, numeros.get(2)+1);
		//Pintaria 1, 2, 4, 2, 1  
		System.out.println(numeros);
		
		//A�ade despues del 2 un 3.
		numeros.add(2,3);
		//A�ade despues del 4 un 3.
		numeros.add(4,3);
		System.out.println(numeros);
	}

}
