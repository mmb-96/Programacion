package EJ13;

import java.util.Set;
import java.util.TreeSet;

public class TestTipoSet {

	public static void main(String[] args) {
		
		Set<String> lista = new TreeSet<String>();
		lista.add("Hola"); lista.add("Mundo"); lista.add("Cruel");
		System.out.println(lista);
		lista.add("Hola");
		System.out.println(lista);
		System.out.println(lista.toArray()[0]);

	}

}
