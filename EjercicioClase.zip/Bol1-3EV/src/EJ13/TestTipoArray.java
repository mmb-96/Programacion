package EJ13;

import java.util.Arrays;

public class TestTipoArray {

	public static void main(String[] args) {
		String[] lista = {"Hola", "Mundo", "Cruel"};
		System.out.println(Arrays.toString(lista));
		String[] copy = Arrays.copyOf(lista, lista.length+1);
		copy[copy.length-1] = "Hola";
		System.out.println(Arrays.toString(copy));
		System.out.println(copy[0]);

	}
}