package EJ13;

import java.util.LinkedList;
import java.util.List;

public class TestTipoList {

	public static void main(String[] args) {
		
		List<String> lista = new LinkedList<String>();
		lista.add("Hola"); lista.add("Mundo"); lista.add("Cruel");
		System.out.println(lista);
		lista.add("Hola");
		System.out.println(lista);
		System.out.println(lista.get(0));
		
	}
}