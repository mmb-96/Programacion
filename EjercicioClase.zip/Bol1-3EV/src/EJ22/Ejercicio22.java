package EJ22;

import java.util.Scanner;

public class Ejercicio22 {

	private static Scanner sx;
	
	public static void main(String[] args) {
		int anioInicio = 0;
		int anioFin = 0;
		sx = new Scanner(System.in);
		
		do {
			System.out.println("Intoduza un anio de inicio: ");
			anioInicio = sx.nextInt();
			System.out.println("Intoduza un anio de fin: ");
			anioFin = sx.nextInt();
		} while (anioFin <= anioInicio);
				
		for (int anio = anioInicio; anio <= anioFin; anio++) {
			if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0))) {
				System.out.println(anio);
			}
		}
	}
}