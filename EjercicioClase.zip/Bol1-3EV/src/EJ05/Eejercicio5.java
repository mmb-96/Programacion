package EJ05;

import java.util.ArrayList;
import java.util.List;

public class Eejercicio5 {
	

	public static void main(String[] args) {
		
		List<Integer> numeros = new ArrayList<Integer>();
		List<Integer> numeros2 = new ArrayList<Integer>();
		numeros.add(1); numeros.add(2); numeros.add(3); numeros.add(4);
		numeros.add(5); numeros.add(6); numeros.add(7); numeros.add(8);
		numeros2.add(1); numeros2.add(2); numeros2.add(3); numeros2.add(4);
		//A�ade los numeros de la coleccion 1 en la 2.
		numeros2.addAll(numeros);
		System.out.println(numeros2);
		//Retiene los numero de la coleccion 1 y los que coincidad de la dos.
		numeros2.retainAll(numeros);
		System.out.println(numeros2);
		//Borra los numeros de la coleccion 1.
		numeros2.removeAll(numeros);
		System.out.println(numeros2);
		
	}
}