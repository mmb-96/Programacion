package EJ06;

import java.util.HashSet;
import java.util.Set;

public class Ejercicio6 {

	public static void main(String[] args) {
		
		Set<Integer> numeros = new HashSet<Integer>();
		Set<Integer> numeros2 = new HashSet<Integer>();
		numeros.add(1); numeros.add(2); numeros.add(3); numeros.add(4);
		numeros.add(5); numeros.add(6); numeros.add(7); numeros.add(8);
		numeros2.add(1); numeros2.add(2); numeros2.add(3); numeros2.add(4);
		//A�ade los numeros de la coleccion 1 en la 2 que no esten en dicha coleccion.
		numeros2.addAll(numeros);
		System.out.println(numeros2);
		//Retiene los numero de la coleccion 1 y los que coincidad de la dos.
		numeros2.retainAll(numeros);
		System.out.println(numeros2);
		//Borra los numeros de la coleccion 1.
		numeros2.removeAll(numeros);
		System.out.println(numeros2);
		
		/*La diferencia es que no a�ade los numeros repetidos.*/
	}

}
