package EJ18;

public class Ejercicio18 {

	
	public static void main(String[] args) {
		String cadena = "Hola ESto es una @�135 prueBA";
		int contador = 0;
		
		for(char letra : cadena.toCharArray()) {
			contador += letrasMayus(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : cadena.toCharArray()) {
			contador += letrasMinusculas(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : cadena.toCharArray()) {
			contador += noLetrass(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : cadena.toCharArray()) {
			contador += vocales(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : cadena.toCharArray()) {
			contador += consonantes(letra);
		}
		System.out.println(contador);

		

	}
	
	public static int letrasMayus(char letra) {
		int num = 0;
		if (Character.isUpperCase(letra)) {
			num++;
		}
		return num;
	}
	
	public static int letrasMinusculas(char letra) {
		int num = 0;
		if (Character.isLowerCase(letra)) {
			num++;
		}
		return num;
	}
	
	public static int noLetrass(char letra) {
		int num = 0;
		if (Character.isLetter(letra) == false) {
			num++;
		}
		return num;
	}
	
	public static int vocales(char letra) {
		int num = 0;
		if (letra == 'a'|| letra == 'e' || letra == 'i' || letra == 'o' ||letra == 'u' || letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' ||letra == 'U') {
			num++;
		}
		return num;
	}
	
	public static int consonantes(char letra) {
		int num = 0;
		if (letra != 'a'&& letra != 'e' && letra != 'i' && letra != 'o' && letra != 'u' && letra != 'A' && letra != 'E' && letra != 'I' && letra != 'O' && letra != 'U') {
			if (Character.isLetter(letra)) {
				num++;
			}		
		}
		return num;
	}

}
