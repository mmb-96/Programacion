package EJ23;

import java.util.LinkedList;
import java.util.List;

public class TestFibonacci {

	public static void main(String[] args) {
		System.out.println(fibo(5));	      
	}
	
	public static List<Long> fibo(int max){
		List<Long> lista = new LinkedList<Long>();
		Long num1 = (long) 0;
		Long num2 = (long) 1; 

	    lista.add(num1);
	    for(int i=2;i<=max;i++){
	    	lista.add(num2);
	        num2 = num1 + num2;
	        num1 = num2 - num1;
	    }
		return lista;
	}

}
