package EJ23;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;

public class asdfasdf {

	public static void main(String[] args) {
		System.out.println("Fibonacci of 100: ");
	      System.out.println(fibonacci(100));
	      System.out.println("Fibonacci of 1000: ");
	      System.out.println(fibonacci(1000));
	}
	
	private static List<BigInteger> fibonacci(int n) {
		List<BigInteger> lista = new LinkedList<BigInteger>();
	    BigInteger a = BigInteger.ZERO;
	    BigInteger b = BigInteger.ONE; 
	    BigInteger c = BigInteger.ONE;
	    lista.add(a);
	    lista.add(b);
	    for (int i=2 ; i<=n ; i++) { 
	    	c =  a.add(b); 
	        a = b; 
	        b = c; 
	        lista.add(c);
	   }
	    	return lista;   
	}

}
