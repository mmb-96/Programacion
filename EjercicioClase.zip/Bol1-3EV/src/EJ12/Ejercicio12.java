package EJ12;

import java.util.Arrays;

public class Ejercicio12 {
	
	public static void main(String[] args) {
		String[] cadena = {"Pepe", "Manuel", "Ana", "Luis", "Casa", "Bea"};
		
		System.out.println(Arrays.toString(cadena));
		System.out.println(Arrays.toString(ordenString(cadena)));
	}
	
	public static String[] ordenString(String[] lista) {
		String[] auxArray = Arrays.copyOf(lista, lista.length);
		for(int i=0;i<(auxArray.length-1);i++){
            for(int j=i+1;j<auxArray.length;j++){
                if(auxArray[i].compareToIgnoreCase(auxArray[j])>0){
                    String aux=auxArray[i];
                    auxArray[i]=auxArray[j];
                    auxArray[j]=aux;

                }
            }
        }
		return auxArray;
	}
}
