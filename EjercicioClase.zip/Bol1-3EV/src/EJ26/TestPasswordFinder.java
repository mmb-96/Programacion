package EJ26;

public class TestPasswordFinder {
	
	private static final String[] PALABRAS = {"hola", "mundo", "cruel","alumno", "profesor", "robot", "parlamentarismo", "jugador"};
	private static final Integer MAX_INTENTOS = 10;
			
	
}
