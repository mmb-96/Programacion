package EJ21;

import java.util.HashSet;
import java.util.Set;

public class Ejercicio21 {

	public static void main(String[] args) {
		String cadena = "Hola ESto es una @�135 prueBA";
		int contador = 0;
		
		Set<Character> setChar = new HashSet<Character>();
		for(char letra : cadena.toCharArray()) {
			setChar.add(letra);
		}
		
		System.out.println(setChar);
		
		for(char letra : setChar) {
			contador += letrasMayus(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : setChar) {
			contador += letrasMinusculas(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : setChar) {
			contador += noLetrass(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : setChar) {
			contador += vocales(letra);
		}
		System.out.println(contador);
		
		contador = 0;
		for(char letra : setChar) {
			contador += consonantes(letra);
		}
		System.out.println(contador);
	}
	
	public static int letrasMayus(char letra) {
		int num = 0;
		if (Character.isUpperCase(letra)) {
			num++;
		}
		return num;
	}
	
	public static int letrasMinusculas(char letra) {
		int num = 0;
		if (Character.isLowerCase(letra)) {
			num++;
		}
		return num;
	}
	
	public static int noLetrass(char letra) {
		int num = 0;
		if (Character.isLetter(letra) == false) {
			num++;
		}
		return num;
	}
	
	public static int vocales(char letra) {
		int num = 0;
		if (letra == 'a'|| letra == 'e' || letra == 'i' || letra == 'o' ||letra == 'u' || letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' ||letra == 'U') {
			num++;
		}
		return num;
	}
	
	public static int consonantes(char letra) {
		int num = 0;
		if (letra != 'a'&& letra != 'e' && letra != 'i' && letra != 'o' && letra != 'u' && letra != 'A' && letra != 'E' && letra != 'I' && letra != 'O' && letra != 'U') {
			if (Character.isLetter(letra)) {
				num++;
			}		
		}
		return num;
	}

}