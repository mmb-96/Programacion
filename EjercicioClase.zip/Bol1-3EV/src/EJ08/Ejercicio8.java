package EJ08;

import java.util.LinkedList;
import java.util.List;

public class Ejercicio8 {

	public static void main(String[] args) {
		LinkedList<Integer> lista = new LinkedList<Integer>();
		
		lista.add(1); lista.add(2); lista.add(3); lista.add(4); lista.add(5); lista.add(6); 
		System.out.println(lista);
		eliminaElementos(lista, 2, 4);
		System.out.println(lista);

	}
	
	public static void eliminaElementos(List<Integer> numeros,Integer numero1,Integer numero2){
		List<Integer> vistaNumeros = numeros.subList(numero1, numero2);
		System.out.println(vistaNumeros);
	}

}
