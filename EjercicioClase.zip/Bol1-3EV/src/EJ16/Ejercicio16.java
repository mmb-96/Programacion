package EJ16;

public class Ejercicio16 {

	public static void main(String[] args) {
		imprimePiramide(10);
		System.out.println("\n");
		imprimePiramideHueca(10);
		System.out.println("\n");
		imprimePiramideARayas(10);
		

	}
	
	public static void imprimePiramide(int altura) {
		for(int numBlancos = altura-2,numAsteriscos=1; numBlancos>=0; numBlancos--, numAsteriscos += 2){
            //Espacios en blanco
            for(int i=1;i<=numBlancos+1;i++){
                System.out.print(" ");
            }
              
            //Asteriscos
            for(int j=1;j<=numAsteriscos;j++) {
            		System.out.print("*");
            }
            
            System.out.println();
            if (numBlancos == 0) {
            	for (int i = 1; i<=numAsteriscos+2; i++) {
            		System.out.print("*");
            	}
            }
        }
	}
	
	public static void imprimePiramideHueca(int altura) {
		for(int numBlancos = altura-2,numAsteriscos=1; numBlancos>=0; numBlancos--, numAsteriscos += 2){
            //Espacios en blanco
            for(int i=1;i<=numBlancos+1;i++){
                System.out.print(" ");
            }
              
            //Asteriscos
            for(int j=1;j<=numAsteriscos;j++){
            	if (j>1 && j <numAsteriscos) {
            		System.out.print(" ");
            	}else {
            		System.out.print("*");
            	}
            }
            
            System.out.println();
            if (numBlancos == 0) {
            	for (int i = 1; i<=numAsteriscos+2; i++) {
            		System.out.print("*");
            	}
            }
        }
	}
	
	public static void imprimePiramideARayas(int altura) {
		for(int numBlancos = altura-1,numAsteriscos=1; numBlancos>=0; numBlancos--, numAsteriscos += 2){
            //Espacios en blanco
            for(int i=1;i<=numBlancos+1;i++){
                System.out.print(" ");
            }
              
            //Asteriscos
            if (numBlancos%2 == 0) {
            	for (int i = 1; i<=numAsteriscos; i++) {
            		System.out.print("*");
            	}
            }else if(numBlancos == 0) {
            	for (int i = 1; i<=numAsteriscos; i++) {
            		System.out.print("*");
            	}
            }else {
            	for(int j=1;j<=numAsteriscos;j++){
                	if (j>1 && j <numAsteriscos) {
                		System.out.print(" ");
                	}else {
                		System.out.print("*");
                	}
                }
            }
            
            System.out.println();
		}
	}
	
}
