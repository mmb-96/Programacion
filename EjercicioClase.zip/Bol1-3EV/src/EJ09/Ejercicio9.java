package EJ09;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Ejercicio9 {

	public static void main(String[] args) {
		Set<LocalDate> agenda1 = new HashSet<LocalDate>();
		Set<LocalDate> agenda2 = new HashSet<LocalDate>();
		Collections.addAll(agenda1, LocalDate.of(2017, 2, 1), LocalDate.of(2017, 2, 2),
		LocalDate.of(2017, 2, 3), LocalDate.of(2017, 2, 5), LocalDate.of(2017, 2, 6), LocalDate.of(2017, 2, 7), LocalDate.of(2017, 2, 10));
		Collections.addAll(agenda2, LocalDate.of(2017, 2, 1), LocalDate.of(2017, 2, 3),
		LocalDate.of(2017, 2, 4), LocalDate.of(2017, 2, 9), LocalDate.of(2017, 2, 10), LocalDate.of(2017, 2, 11), LocalDate.of(2017, 2, 12));
		
		System.out.println(calculaFechasDisponiblesEnAlguno(agenda1, agenda2));
		
		Set<LocalDate> compatible = new HashSet<LocalDate>();
		for (LocalDate lista1 : agenda2) {
			compatible.addAll(calculaFechasCompatibles(agenda1, lista1));
		}
		System.out.println(compatible);
		
		Set<LocalDate> disponibleUno = new HashSet<LocalDate>();
		for (LocalDate lista1 : agenda2) {
			disponibleUno.addAll(calculaFechasDisponiblesSoloEnUno(agenda1, lista1));
		}
		System.out.println(disponibleUno);
	}
	
	public static Set<LocalDate> calculaFechasDisponiblesEnAlguno(Set<LocalDate> col1, Set<LocalDate> col2) {
		Set<LocalDate> resultado = new TreeSet<>();
		resultado.addAll(col1);
		resultado.addAll(col2);
		return resultado;
		
		
	}
	
	public static Set<LocalDate> calculaFechasCompatibles(Set<LocalDate> col1, LocalDate local2) {
		Set<LocalDate> resultado = new TreeSet<>();
		if(col1.contains(local2)) {
			resultado.add(local2);
		}
		return resultado;
	}
	
	public static Set<LocalDate> calculaFechasDisponiblesSoloEnUno(Set<LocalDate> col1, LocalDate local2) {
		Set<LocalDate> resultado = new TreeSet<>();
		if(!col1.contains(local2)) {
			resultado.add(local2);
		}
		return resultado;
	}
}