package EJ24;

public class Ejercicio24 {

	public static void main(String[] args) {
		System.out.println(mcdEuclides(15, 3));

	}
	
	public static int mcdEuclides(int a, int b){
	    while(b != 0){
	         int t = b;
	         b = a % b;
	         a = t;
	    }
	    return a;
	}
}