package EJ25;

import java.util.LinkedList;
import java.util.List;

public class Ejercicio25 {

	public static void main(String[] args) {
		List<String> lista = new LinkedList<String>();
		
		lista.add("Hola"); lista.add("Mundo"); lista.add("Cruel");
		
		for(String palabra : lista) {
			System.out.println(palabra);
		}
		
		String[] listaArray = {"Hola","Mundo","Cruel"};
		for(String palabra : listaArray) {
			System.out.println(palabra);
		}
		
		String cadena = "Hola Mundo Cruel";
		String[] cadena2 = cadena.split(" ");
		for(String palabra : cadena2) {
			System.out.println(palabra);
		}
		
		List<String> lista2 = new LinkedList<String>();
		
		lista2.add("Hola"); lista2.add("Mundo"); lista2.add("Cruel");
		
		for(String palabra : lista2) {
			lista2.remove(palabra);
		}
	}
}