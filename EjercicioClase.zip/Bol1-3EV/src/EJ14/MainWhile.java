package EJ14;

import java.util.LinkedList;
import java.util.List;


public class MainWhile {

	public static void main(String[] args) {
		Matematicas ma = new Matematicas();
		
		System.out.println(ma.esPrimo(5));
		System.out.println(ma.primo(30));
		System.out.println(ma.potencia(2, 3));
		System.out.println(ma.factoria(5));
		System.out.println(ma.perfecto(6));

	}
	
	public static class Matematicas {
		
		public boolean esPrimo(int num) {
			boolean esPrimoActual = true;
			int i = 2;
			
			if(num<2){
				esPrimoActual = false;
			}else{
				while( i * i <= num) {
					if( num % i == 0 ){
						esPrimoActual = false;	
					}
						break;
				}  
					    
			}
			return esPrimoActual; 
		}
		
		public List<Integer> primo(int max) {
			List<Integer> lista = new LinkedList<Integer>();
			int i = 1;
			while (i <= max){
				if(esPrimo(i)){
					lista.add(i);
				}
				i++;
			}
			return lista;
		}
		
		public double potencia(double real, int entero) {
			double resultado = 1;
			int i=1;
	       while(i <= entero) {
	            resultado *= real;
	            i++;;
	        }
	        return resultado; 			
		}
		
		public long factoria(int num) {
			long factorial = 1;
			while (num != 0) {
				factorial *= num;
				num--;
			}
			return factorial;
			
		}
		
		public boolean perfecto(int num) {
			boolean perfecto = false;
			long num2 = 0;
			int divi = 1;
			while(divi < num){
				if(num % divi == 0){
					num2 += divi;
				}
				divi++;
			}
			if (num == num2) {
				perfecto = true;
			}
				
			return perfecto;
		}
	}
}