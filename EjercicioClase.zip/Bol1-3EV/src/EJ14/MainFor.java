package EJ14;

import java.util.LinkedList;
import java.util.List;

public class MainFor {

	public static void main(String[] args) {
		
		Matematicas ma = new Matematicas();
		
		System.out.println(ma.esPrimo(8));
		System.out.println(ma.primo(30));
		System.out.println(ma.potencia(2, 3));
		System.out.println(ma.factoria(5));
		System.out.println(ma.perfecto(6));

	}
	
	public static class Matematicas {
		
		public boolean esPrimo(int num) {
			boolean esPrimoActual = true;
			
			if(num<2){
				esPrimoActual = false;
			}else{
				for(int i = 2; i * i <= num;) {
					if( num % i == 0 ){
						esPrimoActual = false;	
					}
						break;
				}  
					    
			}
			return esPrimoActual; 
		}
		
		public List<Integer> primo(int max) {
			List<Integer> lista = new LinkedList<Integer>();
			int i;
			for(i = 1; i <= max; i++){
				if(esPrimo(i)){
					lista.add(i);
				}
			}
			return lista;
		}
		
		public double potencia(double real, int entero) {
			double resultado = 1;
	        for (int i = 1; i <= entero; i++) {
	            resultado *= real;
	        }
	        return resultado; 			
		}
		
		public long factoria(int num) {
			long factorial = 1;
			for (int i = 2; i <= num; i++) {
				factorial *= i;
			}
			return factorial;
			
		}
		
		public boolean perfecto(int num) {
			boolean perfecto = false;
			long num2 = 0;
			for (int i = 1; i < num; i++) {
				if(num % i == 0) {
					num2 += i;
				}
			}
			if (num == num2) {
				perfecto = true;
			}
				
			return perfecto;
		}
	}
}