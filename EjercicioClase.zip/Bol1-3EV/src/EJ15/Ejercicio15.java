package EJ15;

import java.util.Scanner;

public class Ejercicio15 {
	
	public static void main(String[] args) {
		Ejer15 ej15 = new Ejer15();
		
//		System.out.println(ej15.aleatorio1(140));
		System.out.println(ej15.aleatorio2(140));

	}
	public static class Ejer15 {
		private static final Integer MINIMO_ALEAT = 100;
		private static final Integer MAXIMO_ALEAT = 150;
		private static final Integer MAX_INTENTOS = 5;
		private static int num = 0;
		
		public static int aleatorio1(int numero) {
			while (num < MINIMO_ALEAT || num > MAXIMO_ALEAT) {
				num = (int) (Math.random()*150+1);				
			}
			while (num != numero) {
				
				if (num < numero) {
					System.out.println("Es menor");
				} else if (num > numero) {
					System.out.println("Es mayor");
				}
				Scanner sx = new Scanner(System.in);
				System.out.println("Intoduzca otro numero");
				numero = sx.nextInt();
			}
			return num;
		}
		
		public static int aleatorio2(int numero) {
			int intento = 1;
			while (num < MINIMO_ALEAT || num > MAXIMO_ALEAT) {
				num = (int) (Math.random()*150+1);				
			}
			while (num != numero && intento != MAX_INTENTOS ) {
				
				if (num < numero) {
					System.out.println("Es menor");
					intento++;
				} else if (num > numero) {
					System.out.println("Es mayor");
					intento++;
				}
				Scanner sx = new Scanner(System.in);
				System.out.println("Intoduzca otro numero");
				numero = sx.nextInt();
			}
			return num;
		}
	}
}
