package EJ3;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Ejercicio3 {

	public static void main(String[] args) {
		//3.1
		String cadena = "fundamentos de programaci�n";
		
		cadena = cadena.toUpperCase();
		char[] letras = cadena.toCharArray();
		System.out.println(Arrays.toString(letras));
		
		//3.2
		String cadena2 = "aprendiendo a programar en Java";
		String [] palabra = cadena2.split(" ");
		System.out.println(Arrays.toString(palabra));
		
		//3.3
		Set<String> setPalabras = new LinkedHashSet<String>();
		for(int i=0;i<(palabra.length-1);i++){
            for(int j=i+1;j<palabra.length;j++){
                if(palabra[i].compareToIgnoreCase(palabra[j])>0){
                    String aux=palabra[i];
                    palabra[i]=palabra[j];
                    palabra[j]=aux;

                }
            }
        }
		for(String pala : palabra) {
			setPalabras.add(pala);
		}
		System.out.println(setPalabras);
	}

}
