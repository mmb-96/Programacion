package EJ2;


import java.util.HashSet;
import java.util.LinkedList;

public class Ejercicio2 {

	public static void main(String[] args) {
		//2.1
		LinkedList<Integer> multiposDe2 = new LinkedList<Integer>();
		
		for(int i = 1; i <= 30; i++) {
			if(i%2 == 0) {
				multiposDe2.add(i);
			}
		}
			
		LinkedList<Integer> multiposDe3 = new LinkedList<Integer>();
		
		for(int i = 1; i <= 30; i++) {
			if(i%3 == 0) {
				multiposDe3.add(i);
			}
		}
		
		LinkedList<Integer> multiposDe5 = new LinkedList<Integer>();
		
		for(int i = 1; i <= 30; i++) {
			if(i%5 == 0) {
				multiposDe5.add(i);
			}
		}
		
		LinkedList<Integer> menorQue30 = new LinkedList<Integer>();
		
		for(int i = 1; i < 30; i++) {
			if(i%30 == 0) {
				menorQue30.add(i);
			}
		}
		
		HashSet<Integer> multiposDe235 = new HashSet<Integer>();
		multiposDe235.addAll(multiposDe2);
		multiposDe235.addAll(multiposDe3);
		multiposDe235.addAll(multiposDe5);
		
		
		System.out.println(multiposDe2);
		System.out.println(multiposDe3);
		System.out.println(multiposDe5);
		System.out.println(menorQue30);
		
		//2.2
		LinkedList<Integer> listaA = new LinkedList<Integer>();
		
		for (int num : multiposDe2) {
			for (int num2 : multiposDe3) {
				for (int num3 :multiposDe5) {
					if ( num == num2 && num2 == num3) {
						listaA.add(num3);
					}
				}
			}
		}
		
		System.out.println(listaA);
		
		//2.3
		LinkedList<Integer> listaB = new LinkedList<Integer>();
		
		for (int num : multiposDe235) {
			if (num % 2 == 0 && num % 3 != 0 && num%5 !=0) {
				listaB.add(num);
			}
		}
		
		System.out.println(listaB);
		
		//2.4
		LinkedList<Integer> listaC = new LinkedList<Integer>();
		
		for (int num : multiposDe235) {
			if (num % 2 == 0 || num % 3 == 0 || num % 5 ==0) {
				listaC.add(num);
			}
		}
		
		System.out.println(listaC);
		
		//2.5
		HashSet<Integer> listaD = new HashSet<Integer>();
		listaD.addAll(listaA);
		listaD.addAll(listaB);
		listaD.addAll(listaC);
		
		System.out.println(listaD);
		for(int num : listaD) {
			if (num > 5 && num <30) {
				int contador = 0;
				for(int i = num; i > 0; i--){
				    if(num % i == 0 ){
				        contador++;
				    }
				}
				if(contador == 2){
				   System.out.print(num+", ");
				}
			}
		}		
		
	}

}
