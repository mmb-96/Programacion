package EJ9;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Ejercicio9 {

	public static void main(String[] args) {
		Set<LocalDate> agenda1 = new HashSet<LocalDate>();
		Set<LocalDate> agenda2 = new HashSet<LocalDate>();
		Collections.addAll(agenda1, LocalDate.of(2017, 2, 1), LocalDate.of(2017, 2, 2),
		LocalDate.of(2017, 2, 3), LocalDate.of(2017, 2, 5), LocalDate.of(2017, 2, 6), LocalDate.of(2017, 2, 7), LocalDate.of(2017, 2, 10));
		Collections.addAll(agenda2, LocalDate.of(2017, 2, 1), LocalDate.of(2017, 2, 3),
		LocalDate.of(2017, 2, 4), LocalDate.of(2017, 2, 9), LocalDate.of(2017, 2, 10), LocalDate.of(2017, 2, 11), LocalDate.of(2017, 2, 12));
		
		System.out.println(agenda1.equals(agenda2));
		System.out.println(agenda2);
	}
	
	public static LocalDate calculaFechasDisponiblesEnAlguno(Set col1, Set col2) {
		return null;
		
	}
	
	public static LocalDate calculaFechasCompatibles(Collections col1, Collections col2) {
		
		return null;
	}
	
	public static LocalDate calculaFechasDisponiblesSoloEnUno(Collections col1, Collections col2) {
		return null;
	
	}

}
