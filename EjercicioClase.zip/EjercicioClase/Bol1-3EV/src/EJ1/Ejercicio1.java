package EJ1;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		
		//1.1
		LinkedList<Integer> numeros = new LinkedList<Integer>();
		
		numeros.add(6);
		numeros.add(5);
		numeros.add(4);
		numeros.add(5);
		numeros.add(6);
		numeros.add(7);
		numeros.add(8);
		numeros.add(9);
		numeros.add(8);
		numeros.add(7);
		
		//1.2
		System.out.println(numeros.size());
		
		//1.3
		int max = 0 , min = 0;
		boolean anadir = false;
		
		for(Integer num : numeros) {
			if ( anadir == false ) {
				max = num;
				min = num;
				anadir = true;
			} else {
				if (num > max) {
					max = num;
				}
				if (num < min) {
					min = num;
				}
			}
		}
		
		System.out.println(max);
		System.out.println(min);
		
		//1.4
		if (numeros.contains(0) == false) {
			System.out.println("El valor 0 no esta en la lista");
		} else {
			System.out.println("El valor 0 esta en la lista");
		}
		
		//1.5 
		System.out.println(numeros.indexOf(7));
		System.out.println(numeros.lastIndexOf(7));
		
		//1.6
		numeros.removeFirst();
		System.out.println(numeros);
		
		//1.7
		numeros.removeLast();
		System.out.println(numeros);
		
		//1.8
		Collections.sort(numeros);
		System.out.println(numeros);
		
		//1.9
		numeros.remove((Integer) 7);
		System.out.println(numeros);
		
		//1.10
		LinkedList<Integer> borrar = new LinkedList<Integer>();
		borrar.add(5);
		borrar.add(8);
		numeros.removeAll(borrar);
		System.out.println(numeros);
	}
}