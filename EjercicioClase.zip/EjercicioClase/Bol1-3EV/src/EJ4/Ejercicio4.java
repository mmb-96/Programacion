package EJ4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class Ejercicio4 {
	
	public static void main(String[] args) {
		List<Integer> pares = new ArrayList<>(5);
		List<Integer> impares = new ArrayList<>(5);
		Collections.addAll(pares, 2,8,4,6,10);
		Collections.addAll(impares, 3,1,5,5,5);
		SortedSet<Integer> numeros = new TreeSet<>(pares);
		numeros.addAll(impares);
		System.out.println("El conjunto de n�meros es: " + numeros);
		Integer[] enteros = numeros.toArray(new Integer[10]);
		System.out.println("El array de enteros es: " + Arrays.toString(enteros));
	
		//4.1
		/* El conjunto devuelve 1, 2, 3, 4, 5, 6, 8, 10.
		 * El array devuevle lo mismo pro lod dos ultimo nulos.*/
		//4.2
		/*Las dos primeras 5, las list.
		 * El SortedSet tiene 8.
		 * El Array tiene 10*/
		//4.3
		/*Le pasaria un Collections.sort(numeros) para ordenar la lista.*/
		//4.4
		/*Realizaria un copia de enteros pero en Integer[10] lo pondria Integer[11].*/
	}

}
