import java.util.Scanner;

/**
 * Realizaremos un programa que calcule el valor de los coeficientes binomiales.
 * Los coeficientes binomiales son ampliamente utilizados en distintas ramas de las matem�ticas,
 * como por ejemplo la estad�stica. Se representan como un binomio (dos valores) entre par�ntesis
 * (similar a una fracci�n pero sin la barra horizontal). La f�rmula para calcular el coeficiente
 * binomial de dos valores n y k, lo representaremos como (n,k) es la siguiente: 
 * (n, k) = n! k! / k! (n - k)!
 * 
 * @author Manuel Melero
 */

public class CoeficientesBinomiales {
	
	private static Scanner sx;

	public static void main(String[] args) {
		//variables
		int n;
		int k;
		sx = new Scanner(System.in);
		
		//Implementacion
		do {
			System.out.println("Introduzca dos numeros: ");
			n = sx.nextInt();
			k = sx.nextInt();
		} while (n < 0 || k < 0);
		System.out.println(coeficienteBinomial(n, k));
	}
	
	public static int factorial(int n) {
		if (n == 0) {
			return 1;
		} else {
			return (n * factorial(n-1));
		}
	}
	 
	public static int coeficienteBinomial(int n, int k) {
		return (factorial(n) * factorial(k)) / (factorial(k) * (factorial(n-k)));
	}
}